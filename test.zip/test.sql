-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Ven 17 Mars 2017 à 12:58
-- Version du serveur :  5.7.14
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `NumClient` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `NomClient` varchar(255) NOT NULL,
  `PrenomClient` varchar(255) NOT NULL,
  `AdresseClient` varchar(255) DEFAULT NULL,
  `Cp` varchar(255) DEFAULT NULL,
  `VilleClient` varchar(255) DEFAULT NULL,
  `PaysClient` varchar(255) DEFAULT NULL,
  `pass` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '1' COMMENT 'USER = 1, PREMIUM = 2, MANAGER = 5, ADMIN = 9'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`NumClient`, `email`, `NomClient`, `PrenomClient`, `AdresseClient`, `Cp`, `VilleClient`, `PaysClient`, `pass`, `salt`, `level`) VALUES
(1, '', 'Lehmann', 'Nicolas', '12 a rue du sylvaner', '68980', 'Beblenheim', 'France', '', '', 1),
(2, '', 'toto', 'titi', 'rue de tata', '67000', 'Strasbourg', 'France', '', '', 1),
(3, 'qfeqf@qfq.com', 'ff', 'tt', '12 rue du toto', '67000', 'Strasbourg', 'France', '', '', 1),
(5, '', 'dfsfs', 'fds', 'fds', '55000', 'fds', 'fds', '', '', 1),
(13, '1@1.com', 'jung', 'lucas', 'qqpart', '67200', '', '', '$2y$10$UXJhezFfjY6fiotLeV50YONq.sli1yf7ukEbr5GsGjJ8/pgRN7vtu', 'AkYeVh5KB1BTI', 9),
(14, 'test.com', 'test', 'test', NULL, NULL, NULL, NULL, '$2y$10$mymCbDdxEQE5t0dySPLgpOAC6eJVC14Eg4OSanNAeakGlkSUwm5R.', 'AkYeVh5KB1BTI', 1),
(16, 'touriste@t.com', 'touriste', 'touriste', NULL, NULL, NULL, NULL, '', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `d_categorie`
--

CREATE TABLE `d_categorie` (
  `NumProduit` int(11) NOT NULL,
  `cat_number` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `d_categorie`
--

INSERT INTO `d_categorie` (`NumProduit`, `cat_number`) VALUES
(5, 1),
(5, 3),
(6, 2);

-- --------------------------------------------------------

--
-- Structure de la table `d_facture`
--

CREATE TABLE `d_facture` (
  `Qte` int(11) NOT NULL,
  `NumFacture` int(11) NOT NULL,
  `NumProduit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `d_facture`
--

INSERT INTO `d_facture` (`Qte`, `NumFacture`, `NumProduit`) VALUES
(15, 3, 6),
(30, 3, 7),
(10, 4, 16),
(5, 5, 6),
(5, 6, 6),
(42, 9, 5),
(1, 10, 5),
(1, 11, 7),
(2, 15, 5);

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `NumFacture` int(11) NOT NULL,
  `DateFacture` date NOT NULL,
  `NumClient` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `facture`
--

INSERT INTO `facture` (`NumFacture`, `DateFacture`, `NumClient`) VALUES
(1, '2017-01-18', 1),
(2, '2017-01-05', 1),
(3, '2017-01-05', 5),
(4, '2017-01-05', 3),
(5, '2017-03-13', 13),
(6, '2017-03-13', 13),
(7, '2017-03-13', 2),
(8, '2017-03-13', 2),
(9, '2017-03-13', 2),
(10, '2017-03-13', 13),
(11, '2017-03-13', 13),
(12, '2017-03-13', 13),
(13, '2017-03-13', 13),
(14, '2017-03-13', 13),
(15, '2017-03-13', 5);

-- --------------------------------------------------------

--
-- Structure de la table `niveau`
--

CREATE TABLE `niveau` (
  `level` int(2) NOT NULL,
  `detail_lvl` varchar(20) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `niveau`
--

INSERT INTO `niveau` (`level`, `detail_lvl`) VALUES
(0, 'ne-sert-pas'),
(1, 'Utilisateur'),
(2, 'Premium'),
(9, 'admin'),
(99, 'BANNED');

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

CREATE TABLE `produits` (
  `NumProduit` int(11) NOT NULL,
  `Des` varchar(255) NOT NULL,
  `PUHT` float NOT NULL,
  `detail` varchar(2000) NOT NULL,
  `cat_number` int(20) NOT NULL,
  `stock` int(20) NOT NULL DEFAULT '0',
  `image` varchar(100) NOT NULL DEFAULT 'http://localhost/devoirsql/images/nopics.png',
  `test` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `produits`
--

INSERT INTO `produits` (`NumProduit`, `Des`, `PUHT`, `detail`, `cat_number`, `stock`, `image`, `test`) VALUES
(5, 'Ecran 4K', 499.99, '111111111111111111111111111111111 1 111111111111111111 222222222222 2223333333333333333333333333 3333333333333333333 3333333333333333333333333 344444444444444444 444444444444444444444444 44444444444444444444 444444444444 44444444444444444444444444444444444444444444', 1, 0, 'http://localhost/devoirsql/images/nopics.png', ''),
(6, 'Ram', 105, '1234567890', 3, 11, 'http://localhost/devoirsql/images/ram.jpg', ''),
(7, 'Gpu', 200, '', 0, 0, 'http://localhost/devoirsql/images/nopics.png', ''),
(14, 'Ordinateur 17"', 850, '', 0, 0, 'http://localhost/devoirsql/images/nopics.png', ''),
(15, 'Ordinateur 17"', 850, '', 0, 0, 'http://localhost/devoirsql/images/nopics.png', ''),
(16, 'Arbre Ã  chat', 28, '', 0, 0, 'http://localhost/devoirsql/images/nopics.png', ''),
(18, 'testttt', 5220, 'efsefe', 5, 20, 'http://localhost/devoirsql/images/nopics.png', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `prod_categorie`
--

CREATE TABLE `prod_categorie` (
  `cat_number` int(20) NOT NULL,
  `cat_nom` varchar(40) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `prod_categorie`
--

INSERT INTO `prod_categorie` (`cat_number`, `cat_nom`) VALUES
(2, 'Carte Mere'),
(3, 'Memoire'),
(1, 'Ordinateur Portable'),
(4, 'Stockage externe'),
(5, 'Stockage Interne');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `email` char(20) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `userNum` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `level` int(5) NOT NULL DEFAULT '0' COMMENT 'USER = 0, PREMIUM = 1, MANAGER = 5, ADMIN = 9'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`email`, `pass`, `userNum`, `nom`, `prenom`, `salt`, `level`) VALUES
('test@hh.com', '$2y$10$1jZZuAxpAhSrt.5YTINF9O8DSrIBAoWBhaL8xCcWgUCQxBz.yF1JG', 10, 'ljung', 'lucas', 'AkYeVh5KB1BTI', 9);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`NumClient`),
  ADD KEY `level` (`level`);

--
-- Index pour la table `d_categorie`
--
ALTER TABLE `d_categorie`
  ADD PRIMARY KEY (`cat_number`),
  ADD KEY `NumProduit` (`NumProduit`),
  ADD KEY `cat_number` (`cat_number`);

--
-- Index pour la table `d_facture`
--
ALTER TABLE `d_facture`
  ADD PRIMARY KEY (`NumFacture`,`NumProduit`),
  ADD KEY `NumFacture` (`NumFacture`),
  ADD KEY `NumProduit` (`NumProduit`);

--
-- Index pour la table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`NumFacture`),
  ADD KEY `NumClient` (`NumClient`);

--
-- Index pour la table `niveau`
--
ALTER TABLE `niveau`
  ADD PRIMARY KEY (`level`),
  ADD UNIQUE KEY `level` (`level`);

--
-- Index pour la table `produits`
--
ALTER TABLE `produits`
  ADD PRIMARY KEY (`NumProduit`),
  ADD KEY `prod_categorie` (`cat_number`),
  ADD KEY `test` (`test`);

--
-- Index pour la table `prod_categorie`
--
ALTER TABLE `prod_categorie`
  ADD PRIMARY KEY (`cat_number`),
  ADD UNIQUE KEY `cat_number` (`cat_number`),
  ADD UNIQUE KEY `cat_nom` (`cat_nom`),
  ADD KEY `cat_nom_2` (`cat_nom`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userNum`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `NumClient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `facture`
--
ALTER TABLE `facture`
  MODIFY `NumFacture` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT pour la table `produits`
--
ALTER TABLE `produits`
  MODIFY `NumProduit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `prod_categorie`
--
ALTER TABLE `prod_categorie`
  MODIFY `cat_number` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `userNum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `lvl` FOREIGN KEY (`level`) REFERENCES `niveau` (`level`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Contraintes pour la table `d_categorie`
--
ALTER TABLE `d_categorie`
  ADD CONSTRAINT `numcat` FOREIGN KEY (`cat_number`) REFERENCES `prod_categorie` (`cat_number`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `numpr` FOREIGN KEY (`NumProduit`) REFERENCES `produits` (`NumProduit`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Contraintes pour la table `d_facture`
--
ALTER TABLE `d_facture`
  ADD CONSTRAINT `d_facture_ibfk_1` FOREIGN KEY (`NumFacture`) REFERENCES `facture` (`NumFacture`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `d_facture_ibfk_2` FOREIGN KEY (`NumProduit`) REFERENCES `produits` (`NumProduit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `facture`
--
ALTER TABLE `facture`
  ADD CONSTRAINT `facture_ibfk_1` FOREIGN KEY (`NumClient`) REFERENCES `client` (`NumClient`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `prod_categorie`
--
ALTER TABLE `prod_categorie`
  ADD CONSTRAINT `catnom` FOREIGN KEY (`cat_nom`) REFERENCES `prod_categorie` (`cat_nom`) ON DELETE NO ACTION ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
